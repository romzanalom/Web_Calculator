function appendToResult(value) {
    document.getElementById('result').value += value;
}

function calculate() {
    var result = document.getElementById('result').value;
    var calculatedResult = eval(result); // Evaluate the expression using eval (Note: use caution with eval)
    document.getElementById('result').value = calculatedResult;
}

function clearResult() {
    document.getElementById('result').value = '';
}

function deleteLastCharacter() {
    var result = document.getElementById('result').value;
    document.getElementById('result').value = result.slice(0, -1);
}
